#import <UIKit/UIKit.h>

@interface LiveViewController : UIViewController

@property(nonatomic,copy)NSString* pushUrlString;

@property BOOL isUseingUdp;

@end
