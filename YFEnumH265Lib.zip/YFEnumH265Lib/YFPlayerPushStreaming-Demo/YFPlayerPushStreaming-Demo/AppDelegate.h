//
//  AppDelegate.h
//  YFPlayerPushStreaming-Demo
//
//  Created by suntongmian@163.com on 15/11/30.
//  Copyright (c) 2015年 YunFan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

