//
//  YFRecordViewController.h
//  YFPlayerPushStreaming-Demo
//
//  Created by apple on 3/31/17.
//  Copyright © 2017 YunFan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YFRecordViewController : UIViewController

@property (nonatomic, assign) BOOL isVertical;


@end
